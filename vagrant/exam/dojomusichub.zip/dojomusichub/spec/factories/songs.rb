FactoryBot.define do
  factory :song do
    title { "MyString" }
    artist { "MyString" }
    times_added { 1 }
  end
end
