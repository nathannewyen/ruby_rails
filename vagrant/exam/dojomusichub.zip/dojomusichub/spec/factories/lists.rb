FactoryBot.define do
  factory :list do
    user { nil }
    song { nil }
    count { "MyString" }
  end
end
