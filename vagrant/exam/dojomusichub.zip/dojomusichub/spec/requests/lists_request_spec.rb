require 'rails_helper'

RSpec.describe "Lists", type: :request do

end
